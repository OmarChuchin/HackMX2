package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Juguete extends Objeto {

    int valor=0;
    float x;
    float[] position={.333f,.5f,.75f,.6666f,.2222f,.777777f,.125f,.725f};

    public Juguete(Texture textura) {
        super(textura,9,9);
        x=9;
        this.sprite.setPosition(x,PantallaJuego.ALTO-this.sprite.getHeight());
    }

    public void dibujar(SpriteBatch batch){
        sprite.draw(batch);
    }

    public void reset() {
        x=(PantallaJuego.ANCHO+1)*this.position[this.valor];
        this.sprite.setPosition(x,PantallaJuego.ALTO-this.sprite.getHeight());
        this.valor++;
        if(this.valor>=this.position.length)
            this.valor=0;


    }

    public void caer(){
        this.sprite.setPosition( x,this.sprite.getY()-2.5f*(valor+1));
    }


}
