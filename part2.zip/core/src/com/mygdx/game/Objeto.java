package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;



/*
representa un objeto que forma parte del juego
 */
public class Objeto {

    protected Sprite sprite;

    public Objeto(Texture textura,float x,float y){
        this.sprite=new Sprite(textura);
        this.sprite.setPosition(x,y);
    }

}
