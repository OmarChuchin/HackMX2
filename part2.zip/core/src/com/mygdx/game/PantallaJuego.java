package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

class PantallaJuego implements Screen {

    private final int distance=30;
    private final int wscore=50;
    private final Texture back =new Texture("background.jpg");
    private Score score;
    private MyGdxGame game;
    //tamanio de la pantalla
    public static final float ANCHO=1200,ALTO=800;
    //Camara
    private OrthographicCamera camara;
    private Viewport vista;
    //Administrador de trazos
    private SpriteBatch batch;

    private Juguete toy;
    private Bolo bolo;

    private int puntosJugador=0;

    private Texture BoloT,ToyT;

    //este metodo se ejecuta al mostrarse la vista en la pantalla
    @Override
    public void show() {
        //crear la camara
        camara= new OrthographicCamera(ANCHO,ALTO);
        camara.position.set(ANCHO/2,ALTO/2,0);
        camara.update();
        vista=new StretchViewport(ANCHO,ALTO,camara);
        batch=new SpriteBatch();

        //cargar las texturas
        cargarTexturas();

        //crear todos los objetos
        crearObjetos();

        //Indica quien esta escuchando y atendiendo los eventos
        Gdx.input.setInputProcessor(new ProcesadorEntrada());
    }

    private void crearObjetos() {
        bolo=new Bolo(BoloT);
        toy=new Juguete(ToyT);
        score=new Score();
    }

    private void cargarTexturas(){
        BoloT=new Texture("bolo.png");
        ToyT=new Texture("present.png");

    }

    //Este metodo es el que actualiza la pantalla a 60fps.
    @Override
    public void render(float delta) {

        if(this.puntosJugador<wscore)
            actualizarObjetos();
        //Borrar pantalla
        Gdx.gl.glClearColor(0,0,0,1); //Negro opaco
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if(toy.sprite.getY()<bolo.sprite.getY()+bolo.sprite.getHeight()/2){
            float t2=(bolo.sprite.getX()-toy.sprite.getX());
            float t=toy.sprite.getX()-bolo.sprite.getX()+bolo.sprite.getWidth();
            if((distance>t && t>0) || (0<t2 && t2<distance)){
                toy.reset();
                this.puntosJugador+=5;
            }
        }
        if(toy.sprite.getY()<0){
            toy.reset();
        }

        batch.setProjectionMatrix(camara.combined);

        batch.begin();
        //dibujar ambas raquetas
        //batch.draw(texturaRaqueta,0,ALTO/2);
        //batch.draw(texturaRaqueta,ANCHO-texturaRaqueta.getWidth(),ALTO/2);
        batch.draw(back,0,0);
        bolo.dibujar(batch);
        toy.dibujar(batch);

        score.mostrarMensaje(batch,Integer.toString(this.puntosJugador),ANCHO/4,3*ALTO/4);
        if(this.puntosJugador>=wscore){
            //score.mostrarMensaje(batch,"You win!",ANCHO/2,3*ALTO/4);
            this.game.setScreen(new WinScreen(this.game));
        }
        batch.end();
    }

    private void actualizarObjetos() {
        toy.caer();
    }


    //se ejecuta cuando la ventana cambia de tamanio
    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

    public PantallaJuego(MyGdxGame game) {
        this.game=game;
    }

    //la clase sirve para hacer un objeto que escucha y atiende eventos touch
    class ProcesadorEntrada implements InputProcessor{

        @Override
        public boolean keyDown(int keycode) {
            return false;
        }

        @Override
        public boolean keyUp(int keycode) {
            return false;
        }

        @Override
        public boolean keyTyped(char character) {
            return false;
        }

        @Override
        public boolean touchDown(int screenX, int screenY, int pointer, int button) {
            return false;
        }

        @Override
        public boolean touchUp(int screenX, int screenY, int pointer, int button) {
            return false;
        }

        @Override
        public boolean touchDragged(int screenX, int screenY, int pointer) {
            Vector3 v=new Vector3(screenX,screenY,0);
            camara.unproject(v);
            bolo.sprite.setX(v.x-bolo.sprite.getWidth()/2);
            return false; //ya se proceso el evento
        }

        @Override
        public boolean mouseMoved(int screenX, int screenY) {
            return false;
        }

        @Override
        public boolean scrolled(int amount) {
            return false;
        }
    }
}
