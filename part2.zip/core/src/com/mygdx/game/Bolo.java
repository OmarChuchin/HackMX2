package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Bolo extends Objeto{

    public Bolo(Texture texture){
        super(texture,PantallaJuego.ANCHO/2,0);
    }

    public void dibujar(SpriteBatch batch){
        this.sprite.draw(batch);
    }

}
